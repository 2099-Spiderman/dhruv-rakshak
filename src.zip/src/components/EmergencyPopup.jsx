function EmergencyPopup({ title, message, color, onClose }) {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.82)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 9999,
      }}
    >
      <div
        style={{
          width: "650px",
          background: "#111827",
          borderRadius: "25px",
          border: `6px solid ${color}`,
          padding: "50px",
          textAlign: "center",
          boxShadow: `0 0 60px ${color}`,
        }}
      >
        <h1
          style={{
            color,
            fontSize: "52px",
            marginBottom: "20px",
          }}
        >
          {title}
        </h1>

        <h2
          style={{
            color: "white",
            marginBottom: "40px",
          }}
        >
          {message}
        </h2>

        <button
          onClick={onClose}
          style={{
            background: color,
            color: "white",
            border: "none",
            padding: "15px 35px",
            borderRadius: "12px",
            fontWeight: "bold",
            cursor: "pointer",
            fontSize: "18px",
          }}
        >
          ACKNOWLEDGE
        </button>
      </div>
    </div>
  );
}

export default EmergencyPopup;