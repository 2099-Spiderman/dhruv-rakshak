import { useEffect, useState } from "react";
import Card from "../components/Card";
import db from "../firebase/firestore";
import { doc, onSnapshot } from "firebase/firestore";

function MissionControl() {
  const [robot, setRobot] = useState({
    robot: "Offline",
    battery: 0,
    temperature: 0,
    gps: "Disconnected",
    command: "Idle",
    commandStatus: "Waiting",
  });

  useEffect(() => {
    const ref = doc(db, "robot", "status");

    const unsubscribe = onSnapshot(ref, (snap) => {
      if (snap.exists()) {
        setRobot(snap.data());
      }
    });

    return () => unsubscribe();
  }, []);

  return (
    <Card title="🎯 Mission Control">
      <p><b>🤖 Robot:</b> {robot.robot}</p>
      <p><b>🎮 Command:</b> {robot.command}</p>
      <p><b>📡 Status:</b> {robot.commandStatus}</p>
      <p><b>🔋 Battery:</b> {robot.battery}%</p>
      <p><b>🌡 Temperature:</b> {robot.temperature}°C</p>
      <p><b>📍 GPS:</b> {robot.gps}</p>
    </Card>
  );
}

export default MissionControl;