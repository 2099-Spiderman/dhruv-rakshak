import { useEffect, useState } from "react";
import Card from "../components/Card";

import db from "../firebase/firestore";

import {
  doc,
  updateDoc,
  onSnapshot
} from "firebase/firestore";

function Controls() {

  const ref = doc(db, "robot", "status");

  const [robot,setRobot] = useState({
    command:"Idle",
    commandStatus:"Waiting",
    lastCommand:"None"
  });

  useEffect(()=>{

    const unsubscribe=onSnapshot(ref,(snap)=>{

      if(snap.exists()){

        setRobot(snap.data());

      }

    });

    return ()=>unsubscribe();

  },[]);

  async function sendCommand(command){

      await updateDoc(ref,{
        command,
        lastCommand:command,
        commandStatus:"Executing..."
      });

  }

  return(

<Card title="🎮 Command Center">

<p><b>Last Command</b></p>

<p style={{color:"#60A5FA"}}>

{robot.lastCommand}

</p>

<hr/>

<p>

Status:

<b style={{color:"#22c55e"}}>

 {robot.commandStatus}

</b>

</p>

<div
style={{

display:"grid",

gridTemplateColumns:"1fr 1fr",

gap:"10px",

marginTop:"20px"

}}
>

<button onClick={()=>sendCommand("Start Patrol")}>

▶ Start

</button>

<button onClick={()=>sendCommand("Return Home")}>

🏠 Home

</button>

<button onClick={()=>sendCommand("Charging Dock")}>

🔋 Charge

</button>

<button onClick={()=>sendCommand("Take Picture")}>

📷 Camera

</button>

<button onClick={()=>sendCommand("Stop")}>

⏹ Stop

</button>

<button
style={{
background:"#dc2626",
color:"white",
fontWeight:"bold"
}}
onClick={()=>sendCommand("Emergency Stop")}
>

🚨 STOP

</button>

</div>

</Card>

);

}

export default Controls;