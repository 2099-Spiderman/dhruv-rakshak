import { useEffect, useState } from "react";

import Camera from "./Camera";
import Overview from "./Overview";
import GPS from "./GPS";
import Robot from "./Robot";
import Reports from "./Reports";
import Battery from "./Battery";
import Controls from "./Controls";

import EmergencyPopup from "../components/EmergencyPopup";

import db from "../firebase/firestore";
import { doc, onSnapshot } from "firebase/firestore";

function Dashboard() {
  const [popup, setPopup] = useState(null);

  useEffect(() => {
    const ref = doc(db, "robot", "status");

    const unsubscribe = onSnapshot(ref, (snap) => {
      if (!snap.exists()) return;

      const data = snap.data();

      // Highest Priority
      if (data.helmetMissing > 0) {
        setPopup({
          title: "🚨 HELMET ALERT",
          message: `${data.helmetMissing} worker(s) detected without helmet.`,
          color: "#dc2626",
        });
        return;
      }

      if (data.temperature > 60) {
        setPopup({
          title: "🔥 HIGH TEMPERATURE",
          message: `Robot temperature is ${data.temperature}°C`,
          color: "#ea580c",
        });
        return;
      }

      if (data.battery < 20) {
        setPopup({
          title: "🔋 LOW BATTERY",
          message: `Battery remaining: ${data.battery}%`,
          color: "#ca8a04",
        });
        return;
      }

      if (data.gps === "Disconnected") {
        setPopup({
          title: "📡 GPS LOST",
          message: "Robot GPS connection has been lost.",
          color: "#2563eb",
        });
        return;
      }

      setPopup(null);
    });

    return () => unsubscribe();
  }, []);

  return (
    <>
      {popup && (
        <EmergencyPopup
          title={popup.title}
          message={popup.message}
          color={popup.color}
          onClose={() => setPopup(null)}
        />
      )}

      <div style={{ padding: "40px" }}>
        <h1>🛡️ Dhruv Rakshak</h1>
        <h2>AI Industrial Safety Platform</h2>

        <div
          style={{
            marginTop: "20px",
            marginBottom: "25px",
            background: "#1E3A8A",
            color: "white",
            padding: "15px",
            borderRadius: "12px",
            borderLeft: "6px solid #60A5FA",
            fontWeight: "bold",
          }}
        >
          🔔 System Ready — Waiting for Raspberry Pi connection...
        </div>

        <Overview />

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "15px",
            marginTop: "25px",
            marginBottom: "30px",
            flexWrap: "wrap",
          }}
        >
          <div
            style={{
              background: "#16a34a",
              color: "white",
              padding: "12px 20px",
              borderRadius: "12px",
              fontWeight: "bold",
            }}
          >
            🤖 Robot Online
          </div>

          <div
            style={{
              background: "#2563eb",
              color: "white",
              padding: "12px 20px",
              borderRadius: "12px",
              fontWeight: "bold",
            }}
          >
            📍 GPS Connected
          </div>

          <div
            style={{
              background: "#ca8a04",
              color: "white",
              padding: "12px 20px",
              borderRadius: "12px",
              fontWeight: "bold",
            }}
          >
            🔋 Battery
          </div>

          <div
            style={{
              background: "#dc2626",
              color: "white",
              padding: "12px 20px",
              borderRadius: "12px",
              fontWeight: "bold",
            }}
          >
            🚨 Alerts
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: "20px",
            marginTop: "30px",
            flexWrap: "wrap",
          }}
        >
          <Robot />
          <Reports />
          <Battery />
          <GPS />
          <Camera />
          <Controls />
        </div>
      </div>
    </>
  );
}

export default Dashboard;